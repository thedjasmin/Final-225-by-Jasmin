import time

def trigger_game_over():
    print("\nGame Over!")
    time.sleep(2)
    print("You have been captured and the game ends here.")
    exit()
